require 'spec_helper'

describe TicketsController do

end
