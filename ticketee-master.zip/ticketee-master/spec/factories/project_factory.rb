FactoryGirl.define do
  factory :project do
    name "Example project"
  end
end

